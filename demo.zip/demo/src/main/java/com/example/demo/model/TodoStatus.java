package com.example.demo.model;

public enum TodoStatus {
    AVAILABLE, UNAVAILABLE
}

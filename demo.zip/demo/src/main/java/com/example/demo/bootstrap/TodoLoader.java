package com.example.demo.bootstrap;

import com.example.demo.model.Todo;
import com.example.demo.model.TodoStatus;
import com.example.demo.repositories.TodoRepository;
import lombok.SneakyThrows;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Properties;

@Component
public class TodoLoader implements CommandLineRunner {
    public final TodoRepository todoRepository;

    public TodoLoader(TodoRepository todoRepository) {
        this.todoRepository = todoRepository;
    }

    @Override
    public void run(String... args) {
        loadTodos();
    }

    private void checkHosts() throws UnknownHostException {
        System.out.println("CommandLineRunner is my ip address");
        StringBuilder hostName = new StringBuilder(InetAddress.getLocalHost().toString());
        int index = hostName.indexOf("/");
        int dotIndex = 0, dotPIndex;
        System.out.println(InetAddress.getLocalHost().toString());
        do {
            dotPIndex = dotIndex;
            dotIndex = hostName.indexOf(".", dotPIndex+1);
        }while ( dotIndex != -1 ) ;
        String ipAddress = hostName.substring(index+1, dotPIndex);
        System.out.println(ipAddress + " is my ip address");
        int timeout=1000;
        for (int i=1;i<255;i++){
            String host=ipAddress + "." + i;
            try {
                if (InetAddress.getByName(host).isReachable(timeout)){
                    Todo todo = new Todo(host, getHostFromIp(host), TodoStatus.AVAILABLE);
                    System.out.println(host + " is reachable");
                    todoRepository.save(todo);
                } else {
                    Todo todo = new Todo(host, "Unnamed(due to con)", TodoStatus.UNAVAILABLE);
                    todoRepository.save(todo);
                    sendEmail(host);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public String getHostFromIp(String ipaddr) throws UnknownHostException {
        InetAddress inetAddress = InetAddress.getByName(ipaddr);
        return  inetAddress.getHostName();
    }

    private void loadTodos() {
        if (todoRepository.count() == 0) {
            try {
                checkHosts();
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }
            System.out.println("Sample Todos Loaded");
        } else {
            List<Todo> todoList = todoRepository.findBytodoStatus(TodoStatus.UNAVAILABLE);
            for (Todo todo :
                    todoList) {
                sendEmail(todo.getIpAddress());
            }
        }
    }

    @SneakyThrows
    public void sendEmail(String msg) {
        Properties prop = new Properties();
        prop.put("mail.smtp.auth", true);
        prop.put("mail.smtp.starttls.enable", "true");
        prop.put("mail.smtp.host", "smtp.mailtrap.io");
        prop.put("mail.smtp.port", "25");
        prop.put("mail.smtp.ssl.trust", "smtp.mailtrap.io");
        Session session = Session.getInstance(prop, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                String user = "jove";
                String pass = "forever126";
                return new PasswordAuthentication(user, pass);
            }
        });
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress("toptal126@gmail.com"));
        message.setRecipients(
                Message.RecipientType.TO, InternetAddress.parse("jupiter1206jove@gmail.com"));
        message.setSubject("Mail Subject");

        BodyPart mimeBodyPart = new MimeBodyPart();
        mimeBodyPart.setContent(msg, "text/html");

        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(mimeBodyPart);

        message.setContent(multipart);

        Transport.send(message);
    }
}
